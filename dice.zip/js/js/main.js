



let whoChoice = Math.floor(Math.random() * 2);

let player1 = [document.querySelector('.player1__name'),
document.querySelector('.player1__score'),
document.querySelector('.player1__score-raund')];

let player2 = [document.querySelector('.player2__name'),
document.querySelector('.player2__score'),
document.querySelector('.player2__score-raund')] ;


let ActivePlayer = [player1,player2];



const startBtn = document.querySelector('.start__new-game');
const rollDiceScore = document.querySelector('.roll__score');
const rollDiceBtn =document.querySelector('.roll__dice-btn');




let player1Name = 'hero';
let player2Name = 'Illidan';

let player1Score = 0;
let player2Score = 0;

let player1ScoreRaund = 0;
let player2ScoreRaund = 0;



startBtn.addEventListener('click',startNewGame);

function startNewGame ()

{
rollDiceScore.classList.remove('hide');
rollDiceBtn.classList.remove('hide');
startBtn.classList.add('hide');
}





rollDiceBtn.addEventListener('click',rollDice);

function rollDice ()

{

let rolledScore = Math.ceil(Math.random() * 6);
rollDiceScore.innerHTML = rolledScore;

if(whoChoice == 0) 

{

	console.log(rolledScore + ' очков игроку 1');
	player1Score = player1Score + rolledScore;
	ActivePlayer[0][1].innerHTML = player1Score;

	
	ActivePlayer[0].forEach(e => {
		e.classList.add('active__player');
		});

		ActivePlayer[1].forEach(e => {

			e.classList.remove('active__player');

		});

player1Score.innerHTML=player1Score;

whoChoice = 1;

}

else 

{
	console.log(rolledScore +  ' очков игроку 2');
	player2Score = player2Score + rolledScore;
	ActivePlayer[1][1].innerHTML = player2Score;




	ActivePlayer[1].forEach(e => {
		e.classList.add('active__player');
		});

		ActivePlayer[0].forEach(e => {
			e.classList.remove('active__player');
		});

		whoChoice = 0;
}


rollDiceBtn.setAttribute('disabled', true);

}


function deley( )
{
rolledScore = 0;
rollDiceBtn.removeAttribute('disabled');
rollDiceScore.innerHTML = rolledScore;
}

